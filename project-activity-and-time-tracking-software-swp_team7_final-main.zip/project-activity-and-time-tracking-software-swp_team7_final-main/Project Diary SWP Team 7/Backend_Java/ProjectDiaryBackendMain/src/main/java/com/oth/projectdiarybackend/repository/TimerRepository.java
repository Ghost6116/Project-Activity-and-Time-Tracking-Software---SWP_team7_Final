package com.oth.projectdiarybackend.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oth.projectdiarybackend.entity.TimerEntry;
import com.oth.projectdiarybackend.entity.User;

public interface TimerRepository extends JpaRepository<TimerEntry, Integer> {
	List<TimerEntry> findByUser(User user);
	
}
