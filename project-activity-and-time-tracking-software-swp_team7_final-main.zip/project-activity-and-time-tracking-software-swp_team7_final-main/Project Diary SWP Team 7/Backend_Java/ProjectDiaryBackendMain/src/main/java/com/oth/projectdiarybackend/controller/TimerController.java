package com.oth.projectdiarybackend.controller;


import org.springframework.http.MediaType;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.springframework.http.HttpHeaders;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oth.projectdiarybackend.entity.TimerEntry;
import com.oth.projectdiarybackend.entity.User;
import com.oth.projectdiarybackend.service.PdfReportGenerator;
import com.oth.projectdiarybackend.service.TimerService;
import com.oth.projectdiarybackend.service.UserService;

@RestController
@RequestMapping("/timer")
public class TimerController {
	
	@Autowired
	private TimerService timerService;
	
	@Autowired
    private UserService userService;
	
	@PostMapping("/timer-entry")
	public ResponseEntity<?> saveTimerEntry(@RequestBody TimerEntry timerEntry, @RequestParam String email) {
	    try {
	        // Save the timer entry with the associated user
	        timerService.save(timerEntry, email);
	        return ResponseEntity.ok("Timer entry saved successfully");
	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(500).body("An error occurred: " + e.getMessage());
	    }
	}
	
//	@GetMapping("/timer-entries")
//	public ResponseEntity<?> getAllTimerEntries() {
//	    try {
//	        // Fetch all timer entries using the service
//	        List<TimerEntry> entries = timerService.getAllTimerEntries();
//	        return ResponseEntity.ok(entries); // Return as JSON
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	        return ResponseEntity.status(500).body("An error occurred while fetching timer entries: " + e.getMessage());
//	    }
//	}
	
	@GetMapping("/user-timers")
    public ResponseEntity<?> getUserTimers(@RequestParam String email) {
        User user = userService.findByEmail(email); // Fetch user by email
        if (user == null) {
            return ResponseEntity.badRequest().body("User not found");
        }
        List<TimerEntry> entries = timerService.getEntriesForUser(user);
        return ResponseEntity.ok(entries);
    }
	
    @GetMapping("/generate-report")
    public ResponseEntity<InputStreamResource> generateReport(@RequestParam String email) {
        try {
            // Fetch timer entries for the email
            List<TimerEntry> timerEntries = timerService.getTimerEntriesByEmail(email);

            // Path to the generated PDF file
            String outputPath = "./TimerEntriesReport.pdf";

            // Generate the PDF
            PdfReportGenerator.generatePdfReport(timerEntries, outputPath);

            // Load the file as a resource
            File file = new File(outputPath);
            if (!file.exists()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }

            // InputStreamResource creation without automatic close throwing IOException
            InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

            // Set headers for file download
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=TimerEntriesReport.pdf")
                    .contentLength(file.length())
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(resource);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
