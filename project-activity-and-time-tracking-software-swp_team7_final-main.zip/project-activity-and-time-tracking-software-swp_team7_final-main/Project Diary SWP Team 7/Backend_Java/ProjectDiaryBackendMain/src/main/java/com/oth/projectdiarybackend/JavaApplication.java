package com.oth.projectdiarybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaApplication {

	public static void main(String[] args) {
		System.out.println("Server starting on port 8080");
		SpringApplication.run(JavaApplication.class, args);
	}
}
