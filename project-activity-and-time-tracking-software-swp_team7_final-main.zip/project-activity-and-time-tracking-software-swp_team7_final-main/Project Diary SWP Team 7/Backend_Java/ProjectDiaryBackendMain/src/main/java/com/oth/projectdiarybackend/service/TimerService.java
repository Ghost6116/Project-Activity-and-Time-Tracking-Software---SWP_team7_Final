package com.oth.projectdiarybackend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort;

import com.oth.projectdiarybackend.entity.TimerEntry;
import com.oth.projectdiarybackend.entity.User;
import com.oth.projectdiarybackend.repository.TimerRepository;
import com.oth.projectdiarybackend.repository.UserRepository;

@Service
public class TimerService {
	
	@Autowired
	private TimerRepository timerRepository;
	
	@Autowired
    private UserRepository userRepository;

	public void save(TimerEntry timerEntry, String userEmail) {
        // Save the timer entry to the database
		User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new IllegalArgumentException("User not found with email: " + userEmail));
        
        // Associate the user with the timer entry
        timerEntry.setUser(user);
		System.out.println(timerEntry.toString());
        timerRepository.save(timerEntry);
    }
	
	public List<TimerEntry> getAllTimerEntries() {
        return timerRepository.findAll(Sort.by(Sort.Order.desc("timestamp")));
    }
	
	public List<TimerEntry> getEntriesForUser(User user) {
        return timerRepository.findByUser(user);
    }
	
	public List<TimerEntry> getTimerEntriesByEmail(String email) {
	    User user = userRepository.findByEmail(email)
	        .orElseThrow(() -> new IllegalArgumentException("User not found with email: " + email));
	    return timerRepository.findByUser(user);
	}
	
//	public List<TimerEntry> findByEmail(String email) { 
//        return timerRepository.findByUser_Email(email);
//    }

}
