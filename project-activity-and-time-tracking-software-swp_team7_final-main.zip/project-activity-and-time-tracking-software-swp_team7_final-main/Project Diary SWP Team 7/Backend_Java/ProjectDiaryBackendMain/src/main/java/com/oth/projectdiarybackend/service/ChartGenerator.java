package com.oth.projectdiarybackend.service;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.data.general.DefaultPieDataset;

import java.io.File;

public class ChartGenerator {

    public static void generatePieChart(String outputPath) throws Exception {
        // Create a dataset
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Frontend", 40); // Example data
        dataset.setValue("Backend", 30);
        dataset.setValue("Meetings", 30);

        // Create a pie chart
        var chart = ChartFactory.createPieChart("Task Distribution", dataset, true, true, false);

        // Save chart as PNG image
        ChartUtils.saveChartAsPNG(new File(outputPath), chart, 600, 400);
    }
}
