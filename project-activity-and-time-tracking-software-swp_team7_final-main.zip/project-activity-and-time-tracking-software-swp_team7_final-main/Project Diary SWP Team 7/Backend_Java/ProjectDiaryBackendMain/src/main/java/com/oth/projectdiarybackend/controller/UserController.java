package com.oth.projectdiarybackend.controller;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.oth.projectdiarybackend.entity.User;
import com.oth.projectdiarybackend.service.UserService;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/register-user")
	public ResponseEntity<?> registerUser(@RequestBody User user) {
		System.out.println(user.toString());
	    return userService.addUser(user);
	}
	
	@PostMapping("/login-user")
	public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
	    String email = request.get("email");
	    String password = request.get("password");

	    return userService.loginUser(email, password);
	}

	@GetMapping("/get-all-users")
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}
	
	@DeleteMapping("/delete")
	public void deleteUser(@RequestParam Integer id) {
		userService.deleteUser(id);
	}
	
	@PostMapping("/update")
	public void updateUser(@RequestBody User user) {
		userService.updateUser(user);
	}
	
}
