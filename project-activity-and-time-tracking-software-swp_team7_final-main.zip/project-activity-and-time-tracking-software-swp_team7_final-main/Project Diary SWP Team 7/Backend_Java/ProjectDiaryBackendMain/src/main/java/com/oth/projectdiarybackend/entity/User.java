package com.oth.projectdiarybackend.entity;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.GeneratedValue;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
	@Id
	@GeneratedValue
	@JsonProperty("id")
	private Integer id;
	
	@JsonProperty("name")
	private String name;
	
	@JsonProperty("email")
	@Column(unique=true)
	private String email;
	
	@JsonProperty("password")
	private String password;
	
	@JsonProperty("role")
	private String role;
	
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	
    private List<TimerEntry> timerEntries;
	
	User(String name, String email, String password, String role) {
		this.email = email;
		this.name = name;
		this.password = password;
		this.role = role;
	}
	
	User(){
		
	}

	// Override toString method to print fields of User
    @Override
    public String toString() {
        return "User{" +
                "name='" + this.name + '\'' +
                ", email='" + this.email + '\'' +
                ", password='" + this.password + '\'' +
                 ", role='" + this.role + '\'' +
                '}';
    }

    public Integer getId() {
    	return id;
    }
    
	public String getEmail() {
	    return email;
	}

	public void setEmail(String email) {
	    this.email = email;
	}

	 // Getter for password (getPassword method)
    public String getPassword() {
        return password;
    }

    // Setter for password
    public void setPassword(String password) {
        this.password = password;
    }
    
    // Getter for password (getPassword method)
    public String getRole() {
        return role;
    }

    // Setter for password
    public void setRole(String role) {
        this.role = role;
    }
    
    // Setter for Name
    public void setName(String name) {
        this.name = name;
    }

	public String getName() {
		return name;
	}
}
