package com.oth.projectdiarybackend.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oth.projectdiarybackend.entity.User;


public interface UserRepository extends JpaRepository<User, Integer> {
	Optional<User> findByEmail(String email);
}
