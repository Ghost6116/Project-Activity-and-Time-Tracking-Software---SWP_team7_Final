package com.oth.projectdiarybackend.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "timer_entry")
public class TimerEntry {

		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer id;
		
		@JsonProperty("title")
	    private String title;
		
		@JsonProperty("description")
	    private String description;
		
		@JsonProperty("remarks")
	    private String remarks;
		
		@JsonProperty("category")
	    private String category;
		
		@JsonProperty("duration")
	    private int duration;
		
		@JsonProperty("timestamp")
	    private LocalDateTime timestamp;
	    
		@ManyToOne(optional = false) // Ensures the user field cannot be null
	    @JoinColumn(name = "user_id", nullable = false) // Foreign key column
	    private User user; 
		
		@JsonCreator
	    TimerEntry(
	    		Integer id,
	    		String title,
	    		String description,
	    		String remarks,
	    		String category,
	    		int duration,
	    		LocalDateTime timestamp
	    		)
	    {
			this.id = id;
			this.title = title;
			this.description = description;
			this.remarks = remarks;
			this.category = category;
			this.duration = duration;
			this.timestamp = timestamp;
		}
		
		TimerEntry(){
			
		}
		
		@Override
	    public String toString() {
	        return "User{" +
	                "title='" + this.title + '\'' +
	                ", description='" + this.description + '\'' +
	                ", remarks='" + this.remarks + '\'' +
	                 ", category='" + this.category + '\'' +
	                 ", duration='" + this.duration + '\'' +
	                 ", timestamp='" + this.timestamp + '\'' +
	                '}';
	    }
		
		//Get Sets
		
		public Integer getId() {
	        return id;
	    }

	    public void setId(Integer id) {
	        this.id = id;
	    }

	    public String getTitle() {
	        return title;
	    }

	    public void setTitle(String title) {
	        this.title = title;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }

	    public String getCategory() {
	        return category;
	    }

	    public void setCategory(String category) {
	        this.category = category;
	    }

	    public int getDuration() {
	        return duration;
	    }

	    public void setDuration(int duration) {
	        this.duration = duration;
	    }

	    public LocalDateTime getTimestamp() {
	        return timestamp;
	    }

	    public void setTimestamp(LocalDateTime timestamp) {
	        this.timestamp = timestamp;
	    }

		public void setUser(User user) {
				this.user=user;
			
		}

}
