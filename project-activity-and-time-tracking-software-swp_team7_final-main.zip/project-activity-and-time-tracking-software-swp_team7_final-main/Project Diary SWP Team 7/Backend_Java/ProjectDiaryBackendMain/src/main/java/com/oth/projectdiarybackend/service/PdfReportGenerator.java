package com.oth.projectdiarybackend.service;

import org.apache.pdfbox.pdmodel.PDDocument;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.stereotype.Service;

import com.oth.projectdiarybackend.entity.TimerEntry;

@Service
public class PdfReportGenerator {

    public static void generatePdfReport(List<TimerEntry> timerEntries, String outputFilePath) {
        try (PDDocument document = new PDDocument()) {
            // Add the first page
            PDPage page = new PDPage();
            document.addPage(page);

            // Write the header and chart to the first page
            float margin = 50;
            float yStart = 750;
            float yPosition = yStart;
            float tableTop = 400;
            float cellHeight = 20;

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                // Add header
                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 14);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Timer Entries Report");
                contentStream.endText();

                // Add pie chart
                BufferedImage chartImage = generatePieChart(timerEntries);
                PDImageXObject pdImage = PDImageXObject.createFromByteArray(document,
                        bufferedImageToBytes(chartImage), "chart");
                contentStream.drawImage(pdImage, margin, tableTop, 500, 300);
            }

            // Draw the table with lines
            PDPageContentStream tableContentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true);
            yPosition = tableTop - 50;

            float[] columnWidths = {150, 100, 100, 150};
            String[] headers = {"Title", "Category", "Duration", "Remarks"};

            // Draw table headers with lines
            drawRowWithLines(tableContentStream, headers, margin, yPosition, columnWidths, true);
            yPosition -= cellHeight;

            // Draw table rows with data
            for (TimerEntry entry : timerEntries) {
                if (yPosition < 50) { // If space is not enough, add a new page
                    tableContentStream.close();
                    page = new PDPage();
                    document.addPage(page);
                    tableContentStream = new PDPageContentStream(document, page);
                    yPosition = yStart;
                }

                String[] rowData = {
                        entry.getTitle() != null ? entry.getTitle() : "N/A",
                        entry.getCategory() != null ? entry.getCategory() : "N/A",
                        String.valueOf(entry.getDuration()),
                        entry.getRemarks() != null ? entry.getRemarks() : "N/A"
                };
                drawRowWithLines(tableContentStream, rowData, margin, yPosition, columnWidths, false);
                yPosition -= cellHeight;
            }

            tableContentStream.close();

            // Save the document
            document.save(outputFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void drawRowWithLines(PDPageContentStream contentStream, String[] data, float x, float y, float[] columnWidths, boolean isHeader) throws IOException {
        float textX = x;
        float textY = y - 15; // Adjust text to be inside the cell

        contentStream.setFont(isHeader ? PDType1Font.HELVETICA_BOLD : PDType1Font.HELVETICA, 12);

        for (int i = 0; i < data.length; i++) {
            // Draw cell borders
            contentStream.addRect(x, y - 20, columnWidths[i], 20);
            contentStream.stroke();

            // Add text
            contentStream.beginText();
            contentStream.newLineAtOffset(textX + 5, textY);
            contentStream.showText(data[i]);
            contentStream.endText();

            x += columnWidths[i]; // Move to the next cell
            textX += columnWidths[i];
        }
    }

    private static BufferedImage generatePieChart(List<TimerEntry> timerEntries) {
        DefaultPieDataset dataset = new DefaultPieDataset();

        for (TimerEntry entry : timerEntries) {
            dataset.setValue(entry.getCategory(), entry.getDuration());
        }

        JFreeChart pieChart = ChartFactory.createPieChart(
                "Task Distribution by Category",
                dataset,
                true, true, false);

        PiePlot plot = (PiePlot) pieChart.getPlot();
        plot.setCircular(true);

        // Set custom colors for the chart
        plot.setSectionPaint("frontend", new Color(102, 204, 255)); // Light Blue
        plot.setSectionPaint("backend", new Color(255, 153, 102)); // Orange
        plot.setSectionPaint("meeting", new Color(153, 255, 153)); // Light Green
        plot.setBackgroundPaint(Color.WHITE); // Chart background color

        return pieChart.createBufferedImage(800, 600);
    }

    private static byte[] bufferedImageToBytes(BufferedImage image) throws IOException {
        try (java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream()) {
            ImageIO.write(image, "png", baos);
            return baos.toByteArray();
        }
    }
}
