package com.oth.projectdiarybackend.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.oth.projectdiarybackend.entity.User;
import com.oth.projectdiarybackend.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	
	public ResponseEntity<?> addUser(User user) {
	    Optional<User> existingUser = userRepository.findByEmail(user.getEmail());
	    if (existingUser.isPresent()) {
	        return ResponseEntity.badRequest().body(Collections.singletonMap("error", "Email is already registered. Please use a different email."));
	    }
	    userRepository.save(user);
	    return ResponseEntity.ok(Collections.singletonMap("message", "User registered successfully"));
	}
	
	public ResponseEntity<?> loginUser(String email, String password) {
		
		Optional<User> optionalUser = userRepository.findByEmail(email);
		if (optionalUser.isEmpty()) {
            return ResponseEntity.status(404)
                    .body(Collections.singletonMap("error", "User not found. Please register before logging in."));
	    }
		User user = optionalUser.get();
		if (!user.getPassword().equals(password)) {
            return ResponseEntity.status(401)
                    .body(Collections.singletonMap("error", "Invalid credentials. Please try again."));
        }
		System.out.println("User logged in successfully: " + user.getEmail());
		System.out.println(optionalUser.toString());
		// On successful login, return a success response
		
	    return ResponseEntity.ok(Collections.singletonMap("role", user.getRole()));
        
    }
	
	public User findByEmail(String email) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        return optionalUser.orElse(null);
    }
	
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public void deleteUser(Integer id) {
		System.out.println("deleteUser called with id: " + id);
		userRepository.deleteById(id);
	}

	public void updateUser(User user) {
		// Find the user by ID
        User existingUser = userRepository.findById(user.getId()).orElseThrow(() -> new RuntimeException("User not found"));

        // Update the user fields
        existingUser.setName(user.getName());
        existingUser.setEmail(user.getEmail());
        existingUser.setPassword(user.getPassword());

        // Save the updated user
        userRepository.save(existingUser);
	}
}
		

