package com.oth.projectdiarybackend.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Disable CSRF for development purposes
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/user/**").permitAll() // Allow public access to /user/** endpoints
                .requestMatchers("/timer/**").permitAll() // Allow public access to /user/** endpoints
                .anyRequest().authenticated() // Require authentication for other endpoints
            )
            .cors(Customizer.withDefaults()); // Apply CORS configuration

        return http.build();
    }
}